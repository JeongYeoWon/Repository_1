#pragma once

void CHECKERROR(int e);